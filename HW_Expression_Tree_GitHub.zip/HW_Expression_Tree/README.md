# Expression Tree (Java)

A Java program that builds an expression tree from a postfix expression,
evaluates the expression, and prints its infix representation.

## Requirements

- Java JDK 8 or later

## Compile and run

```bash
javac HW.java
java HW
```

## Expected output

```text
Infix: ((5+3)*(8-2))
Result: 48
```

## GitHub

1. Create a new repository on GitHub.
2. Extract this ZIP file.
3. Upload `HW.java` and `README.md` to the repository, or use Git:

```bash
git init
git add .
git commit -m "Add Java expression tree"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```
